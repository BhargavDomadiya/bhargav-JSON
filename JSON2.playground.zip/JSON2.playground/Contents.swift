import UIKit

var greeting = "Hello, playground"
//1------------------------------------------------------
struct UserDetails{
    var user: [User]
}

struct User{
    var firstNAme: String
    var lastName: String
    var joined: [Joined]
    var image: [Image]
}

struct Joined{
    var month: String
    var day: Int
    var year: Float
}

//2------------------------------------------------------
struct Widget {
    var debug: String
    var window: [Window]
}
struct Window{
    var title: String
    var name: String
    var width: Int
    var height: Int
}
struct Image{
    var src: String
    var name: String
    var hOffSet: Int
    var vOffSet: Int
    var allignment: String
}
struct Text {
    var data: String
    var size: Int
    var style: StringStyle
    var name: String
    var hOffset: Int
    var vOffset: Int
    var allignment: String
    var onMouseUp: String
}



//3------------------------------------------------------
struct ConstantObject{
    var first: First
}
struct First{
    var first: String
    var second: Second
}
struct Second{
    var second: Bool
    var third: Third
}
struct Third{
    var third: String
    var fourth: Fourth
}
struct Fourth{
    var fourth: Int
}



//4-------------------------------------------------------
struct Information{
    var status: String
    var data: [Data]
}
struct Data{
    var city: String
    var state: String
    var country: String
    var location: Location
    var current: Current
}
struct Location{
    var type: String
    var cordinates: [Double]
}
struct Current{
    var weather: Weather
    var pollution: Pollution
}
struct Weather{
    var tc: String
    var hu: Int
    var ic: String
    var pr: Int
    var tp: Int
    var wd: Int
    var ws: Float
}

struct Pollution{
    var ts: String
    var aqius: Int
    var mainus: String
    var aqicn: Int
    var maincn: String
}
